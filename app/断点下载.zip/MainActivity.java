package com.example.janev.myapplication;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private java.lang.String TAG = "123";


    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE};
    //请求状态码
    private static int REQUEST_PERMISSION_CODE = 1;
    private TextView tvTotal;
    private TextView tvCurr;
    private TextView tvSpeed;
    private ProgressBar pbTotal;
    private ProgressBar pbCurr;

    private long mSpeed = 0;
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            tvSpeed.setText(""+mSpeed);
            mSpeed = 0;
            handler.sendEmptyMessageDelayed(1,1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        APP.regisite(this);

        tvTotal = (TextView) findViewById(R.id.tv_total);
        tvCurr = (TextView) findViewById(R.id.tv_curr);
        tvSpeed = (TextView) findViewById(R.id.tv_speed);
        pbTotal = (ProgressBar) findViewById(R.id.pb_totalNum);
        pbCurr = (ProgressBar) findViewById(R.id.pb_current);

        List<String> urlList = new ArrayList<>();
        urlList.add("https://downpack.baidu.com/appsearch_AndroidPhone_1012271b.apk");
        urlList.add("http://soft.duote.com.cn/aiqiyi_6.5.68.5801_7.exe");
        urlList.add("http://app.2345.cn/appgame/82667.apk");
        urlList.add("http://app.2345.cn/appgame/82059.apk");

        handler.sendEmptyMessageDelayed(1,1000);
        BPDownloadUtil.getInstance().breakPointDownload(urlList, new BPDownloadUtil.MutiFileDownloadListener() {
            @Override
            public void onBefore(final int totalNum) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvTotal.setText(totalNum+"个文件");
                        pbTotal.setMax(totalNum);
                        pbCurr.setMax(100);
                    }
                });

            }

            @Override
            public void onProgress(final int currNum, final int progress) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvCurr.setText("当前第"+currNum+"个文件");
                        pbTotal.setProgress(currNum);
                        pbCurr.setProgress(progress);
                    }
                });

            }

            @Override
            public void onDownloadSpeed(final long speed) {
                mSpeed += speed;
            }

            @Override
            public void onSuccess(final int currFileNum) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        pbTotal.setProgress(currFileNum);
                        pbCurr.setProgress(100);
                        tvCurr.setText("第 " + currFileNum + " 个文件下载完成");
                    }
                });
            }

            @Override
            public void onFinish() {
            }

            @Override
            public void onError(int currFileNum, Exception e) {
                if (e instanceof FileNotFoundException) {
                    if (e.getMessage().contains("Permission denied")) {
                        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
                            if (ActivityCompat.checkSelfPermission(APP.getAppContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                                ActivityCompat.requestPermissions(APP.activity, PERMISSIONS_STORAGE, REQUEST_PERMISSION_CODE);
                            }
                        }
                    }
                }

            }
        });
    }
}
